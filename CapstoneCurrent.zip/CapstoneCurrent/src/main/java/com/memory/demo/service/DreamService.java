package com.memory.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.memory.demo.model.Dream;

import com.memory.demo.repository.DreamRepository;

@Service
public class DreamService {

	@Autowired
	DreamRepository dreamRepository;
	
	public void addNight(Dream dream) {
		dreamRepository.save(dream);

	}

	public Optional<Dream> getUserById(Long dId) {
		return dreamRepository.findById(dId);
	}
	
	
	public List<Dream> getAllDreams() {
		   List<Dream> dreams = new ArrayList<Dream>();
		   dreamRepository.findAll().forEach(dreams::add);
	       return dreams;
	}

	public void setDreamRepository(DreamRepository dreamRepository) {
		this.dreamRepository = dreamRepository;
		
	}
}
