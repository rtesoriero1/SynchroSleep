package com.memory.demo;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.memory.demo.model.Night;
import com.memory.demo.model.Profile;
import com.memory.demo.repository.NightRepository;
import com.memory.demo.service.NightService;
import com.memory.demo.service.ProfileService;

@SpringBootApplication
public class CapstoneCurrentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CapstoneCurrentApplication.class, args);
		
		ProfileService pService = new ProfileService();   
		NightService nightservice = new NightService(); 
		Profile profile = new Profile();
		Night night = new Night ();
	
		
		profile.setPName("Mr. Test" );
		profile.setPAge(32);
		profile.setPSex("Male");
		profile.setPWeight(145);
		profile.setPActivity("Average");


		night.setNWake("08:00");
		//night.setNWake("8AM");
		
		night.setProfile(profile);
		
		night.setNBed(nightservice.nightCalc(profile, night, night.getNWake()));;
		
		System.out.println(nightservice.nightCalc(profile, night, night.getNWake()));
		//pService.addProfile(profile);
		//nightservice.addNight(night);
	}

}
