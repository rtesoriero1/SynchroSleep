package com.memory.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.memory.demo.model.BankInfo;


@Repository
public interface BankRepository extends JpaRepository<BankInfo, Long> {
	
	Optional<BankInfo> findById (Long cId);

}
