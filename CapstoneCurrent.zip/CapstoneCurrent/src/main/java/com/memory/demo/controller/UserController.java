package com.memory.demo.controller;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.security.SecureRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

import com.memory.demo.model.User;
import com.memory.demo.repository.ProfileRepository;
import com.memory.demo.service.ProfileService;
import com.memory.demo.service.UserService;

import jakarta.servlet.http.HttpSession;







@Controller
public class UserController {

	
	//http://127.0.0.1:8080/login
	
	
	@Autowired
	UserService userService; 
	
	@Autowired
	ProfileService profileService;
	
	@Autowired
	ProfileRepository profileRepository;
	
	
	
	@GetMapping("/")
	public String getHomePage() {
		return "login";
	}
	
	
	@GetMapping("/success")
	public String getSuccess() {
		return "success";
	}
	
	
	
	@GetMapping("/register")
	public String getRegisterPage(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "register";
	}
	
	
	
	
	@PostMapping("/login")
	public String login(@RequestParam String email, @RequestParam String password, Model model)  {
	   
		
		
		if(userService.findUserByEmail(email) == null) {
			//Handling exceptions through error message 
			model.addAttribute("LoginError", "Wrong Email or Password");
			return"login";
		} 
		
		
		User currentUser = userService.findUserByEmail(email);
		
		
	
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
       
        String enteredPassword = currentUser.getPassword();
        
       
        if(!encoder.matches(password, enteredPassword)) {
        	//Handling exceptions through error message
        	model.addAttribute("LoginError", "Wrong Email or Password");
			return"login";
        	
        	
        } 
	   
        return "redirect:/hub";
	
        
	}
	
	
	@PostMapping("/register")
	public String saveNewUser (@ModelAttribute("user") User user,BindingResult result,Model model) {
		

		//Need to check to make sure this User does not already exist
		User currentUser = userService.findUserByEmail(user.getEmail());
		if(currentUser != null && currentUser.getEmail() != null && !currentUser.getEmail().isEmpty()){
           
			model.addAttribute("EmailError", "There is already an Account for this Email");
			return"register";
			
        }
		
		//Error handling 
		  if(result.hasErrors()){
			  
	            model.addAttribute("user", user);
	        
		  }
	            
		  //Password encryption
		  int strength = 10;
          BCryptPasswordEncoder bcryptEncoder = new BCryptPasswordEncoder(strength, new SecureRandom());
		 String enteredPassword = user.getPassword();
          String encodedPassword = bcryptEncoder.encode(enteredPassword);
          user.setPassword(encodedPassword);
         
		  
		userService.addUser(user);
		return "redirect:/create";
	}
	
	
}
