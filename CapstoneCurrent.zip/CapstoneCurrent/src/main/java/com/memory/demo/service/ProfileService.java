package com.memory.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.memory.demo.model.Profile;
import com.memory.demo.repository.ProfileRepository;


@Service
public class ProfileService{

	@Autowired 
	private ProfileRepository profileRepository;
	
	
	public List<Profile> getAllProfilesByUser(@Param("user_id")Long pId) {
		return profileRepository.getAllProfilesByUser(pId);
	}
	
	
	List<Profile> deleteAllProfilesByUser(@Param("user_id")Long pId) {
		return profileRepository.deleteAllProfilesByUser(pId);
	}
	
		
	public List<Profile> getAllProfiles() {
		   List<Profile> profiles = new ArrayList<Profile>();
		   profileRepository.findAll().forEach(profiles::add);
	       return profiles;
	}
	 
	 public Optional<Profile> getProfileById(Long pId){
		 return profileRepository.findById(pId);
	 }
	 
	 public void addProfile (Profile profile)
	 {
		 profileRepository.save(profile);
	 }
	 
	 public void updateProfile (Long pId, Profile profile)
	 {
		 
		 Optional<Profile> profileData = profileRepository.findById(pId);

	       if (profileData.isPresent()) {
	          Profile targetProfile = profileData.get();
	        targetProfile.setPName(profile.getPName());
	        targetProfile.setPAge(profile.getPAge());
	        targetProfile.setPActivity(profile.getPActivity());
	        targetProfile.setPSex(profile.getPSex());
	        targetProfile.setPWeight(profile.getPWeight());
	           addProfile(targetProfile);
	       }
		
	 }
	 
	 public void deleteProfile (Long pId) {
		 profileRepository.deleteById(pId);
	 }


	public void setProfileRepository(ProfileRepository profileRepository) {
		this.profileRepository = profileRepository;
		
	}
	 
	

	
}
