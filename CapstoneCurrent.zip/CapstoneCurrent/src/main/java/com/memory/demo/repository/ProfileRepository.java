package com.memory.demo.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.memory.demo.model.Profile;


@Repository
public interface ProfileRepository extends JpaRepository<Profile, Long> {

	@Query(value = "SELECT * FROM profiles WHERE user_id = :user_id; ", nativeQuery = true)
	List<Profile> getAllProfilesByUser(@Param("user_id")Long pId);
	
	@Query(value = "DELETE FROM profiles WHERE user_id = :user_id; ", nativeQuery = true)
	List<Profile> deleteAllProfilesByUser(@Param("user_id")Long pId);
	
		


}
