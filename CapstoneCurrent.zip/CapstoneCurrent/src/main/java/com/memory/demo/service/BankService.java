package com.memory.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.memory.demo.model.BankInfo;
import com.memory.demo.repository.BankRepository;

@Service
public class BankService {

	@Autowired	
	private BankRepository bankRepository;
	
	public void addBankInfo(BankInfo bank) {
		bankRepository.save(bank);
	}
	
	public Optional<BankInfo> findBankById(Long id) {
		return bankRepository.findById(id);
	}

	public void setBankRepository(BankRepository bankRepository) {
		this.bankRepository = bankRepository;
		
	}
}
