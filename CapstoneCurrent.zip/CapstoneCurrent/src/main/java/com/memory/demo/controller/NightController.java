package com.memory.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.memory.demo.model.Night;
import com.memory.demo.model.Profile;
import com.memory.demo.service.NightService;
import com.memory.demo.service.ProfileService;

@Controller
public class NightController {

	
@Autowired
private NightService nightService;

@Autowired
private ProfileService profileService;
	
	@GetMapping("/night/{pId}")
	public String showNightCalculator (@PathVariable( "pId") Long pId,  Model model) {
		Optional<Profile> profile =	profileService.getProfileById(pId);
		Profile _profile = profile.get();
		Night night = new Night();
		model.addAttribute("profile", _profile);
		model.addAttribute("night", night);
		return "night"; 
		
		//giving me nWake
	}
	
	
	@PostMapping("/night/save/{pId}")
	public String saveNight(@ModelAttribute("night") Night night, @RequestParam( "pId") Long pId,  BindingResult result,Model model) {
		
	
	Optional<Profile> profile =	profileService.getProfileById(pId);
		Profile _profile = profile.get();
		
		//save nWake to the DB 
		nightService.addNight(night);
		//use nWake to help generate nBed 
		night.setNBed(nightService.nightCalc(_profile, night, night.getNWake()));
		
		
		//We need to get this String so that the results page knows which Night to get the bedtime from.
		String nId = String.valueOf(night.getNId());
		
		///save to the DB with nBed 
		nightService.addNight(night);
		
		//I attach the nId string to the redirect so that its in the url and the results display for the Night with that Id
		return "redirect:/bedtime/" + nId;
	}
	
	
	@GetMapping("/bedtime/{nId}")
	public String showBedTime (@PathVariable("nId") Long nId, Model model) {
		//Used to load in the information of that specific Night 
		Optional<Night> night = nightService.getNightById(nId);
		
		Night night_ = night.get();
		model.addAttribute("night", night_);
		
		
		return "bedtime";
	}
}
