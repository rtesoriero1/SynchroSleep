package com.memory.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.memory.demo.model.Night;


@Repository
public interface NightRepository extends JpaRepository<Night, Long>{

	Optional<Night>findById (Long nId);
	
}
